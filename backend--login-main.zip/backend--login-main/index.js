const express = require('express')
const mongoose = require('mongoose')
const bodyparser = require('body-parser')
require('dotenv').config()

const app = express()

// capturar body
app.use(bodyparser.urlencoded({
    extended: false
}))
app.use(bodyparser.json())

//conexion bd
const url = `mongodb+srv://`
mongoose.connect(url,{
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => console.log('conectado B)'))
.catch((error) => console.log('error no le sabes' + error))
//rutas
const authRoutes = require('./routes/auth')

//rutas middlewar
app.use('/api/user', authRoutes)

app.get('/', (req, res) => {
    res.json({
        estado: true,
        mensaje: 'funciona'
    })
})

// servidor on
const PORT = process.env.PORT || 3005
app.listen(PORT, () =>{
    console.log(`Serv en ejecucion: ${PORT}`)
})