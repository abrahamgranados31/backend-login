<template>
    <v-row class="renglon" >
        <nuxt />
    </v-row>
</template>

<style scoped>
    .renglon{
        width: 100vw;
        height: 100vh;
        flex-direction: row;
        align-content: center;
        justify-content: center;
        align-items: center;
    }
</style>