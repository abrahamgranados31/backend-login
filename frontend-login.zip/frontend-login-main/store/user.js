export const state = () =>  ({
    User:  []
})

export const mutations = {
    setUser (state, user){
        state.user = user
    }
}