<template>
    <h1>hola</h1>
</template>

<script>
export default {
    auth: true,
    layout: 'dashboard'
}
</script>